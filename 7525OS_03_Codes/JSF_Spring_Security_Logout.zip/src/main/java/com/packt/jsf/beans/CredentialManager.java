package com.packt.jsf.beans;

import java.io.IOException;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import org.springframework.security.authentication.BadCredentialsException;
import javax.faces.application.FacesMessage;

import org.springframework.security.web.WebAttributes;

public class CredentialManager implements PhaseListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String j_username;
	private String j_password;
	
	 public String getJ_password() {
		return j_password;
	}
	public void setJ_password(String j_password) {
		this.j_password = j_password;
	}
	public String doSpringSecurityLogin() throws IOException, ServletException
	    {
	        ExternalContext context = FacesContext.getCurrentInstance().getExternalContext();
	        RequestDispatcher dispatcher = ((ServletRequest) context.getRequest()).getRequestDispatcher("/j_spring_security_check");
	        dispatcher.forward((ServletRequest) context.getRequest(),(ServletResponse) context.getResponse());
	        FacesContext.getCurrentInstance().responseComplete();
	        return null;
	    }
	public String doSpringSecurityLogout() throws IOException, ServletException
    {
        ExternalContext context = FacesContext.getCurrentInstance().getExternalContext();
        RequestDispatcher dispatcher = ((ServletRequest) context.getRequest()).getRequestDispatcher("/j_spring_security_logout");
        dispatcher.forward((ServletRequest) context.getRequest(),(ServletResponse) context.getResponse());
        FacesContext.getCurrentInstance().responseComplete();
        return null;
    }
	public String getJ_username() {
		return j_username;
	}
	public void setJ_username(String j_username) {
		this.j_username = j_username;
	}
	public void afterPhase(PhaseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	public void beforePhase(PhaseEvent arg0) {
		Exception e = (Exception) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get(
				WebAttributes.AUTHENTICATION_EXCEPTION);
 
		 if (e instanceof BadCredentialsException) {
	        	System.out.println("error block"+e);
	            FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put(
	            		WebAttributes.AUTHENTICATION_EXCEPTION, null);
	            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,"Username or password not valid.", "Username or password not valid"));
	        }
	}
	public PhaseId getPhaseId() {
		 return PhaseId.RENDER_RESPONSE;
	}
	
}
