package com.packt.action;

public class HelloAction {

		public String execute(){
		return "SUCCESS";
		
	}
}
